READ ME

The app.R file is a Shiny script file , to set the directory path with text file and dataset . Then open in R-studio to run the app file.

Mainly It contans four navi bar in home page
First Navibar:
The shiny app show the dataset in Tableview,visulization and summary of the dataset .

Second Navibar:
Exploration bar disply with 4 text files in drop down options like(positive and negative raw user reviews , Filtered positve and negative files ) in Word Cloud .

Third Navibar: 
The Bags-of-words navigation shows the user input words are present in BoW file or not. Then it display word frequency in dygraph.  

Fourth Navibar:
General upload options and About the App information.


PS: The concept of app shows with visual in shiny , so modeling the dataset for train and test and machine learning algorithm are used in R Scripts.Not in R-Shiny.